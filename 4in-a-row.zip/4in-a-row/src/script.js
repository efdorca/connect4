const rows = 6;
const cols = 7;
let currentPlayer = "red";
let board = [];

const boardElement = document.getElementById("board");
const statusText = document.getElementById("current-player");
const resetButton = document.getElementById("reset");

// Initialize board state
function createBoard() {
    board = Array(rows).fill(null).map(() => Array(cols).fill(null));
    boardElement.innerHTML = "";
    
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.dataset.row = r;
            cell.dataset.col = c;
            cell.addEventListener("click", handleMove);
            boardElement.appendChild(cell);
        }
    }
}

// Handle player move
function handleMove(event) {
    const col = event.target.dataset.col;
    
    for (let r = rows - 1; r >= 0; r--) {
        if (!board[r][col]) {
            board[r][col] = currentPlayer;
            updateBoard();
            if (checkWin()) {
                alert(`${currentPlayer.toUpperCase()} Wins!`);
                disableBoard();
                return;
            }
            currentPlayer = currentPlayer === "red" ? "yellow" : "red";
            statusText.textContent = currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1);
            return;
        }
    }
}

// Update board UI
function updateBoard() {
    document.querySelectorAll(".cell").forEach(cell => {
        const r = cell.dataset.row;
        const c = cell.dataset.col;
        cell.classList.remove("red", "yellow");
        if (board[r][c]) {
            cell.classList.add(board[r][c]);
        }
    });
}

// Check for win condition
function checkWin() {
    function checkDirection(r, c, dr, dc) {
        let color = board[r][c];
        if (!color) return false;
        for (let i = 1; i < 4; i++) {
            if (board[r + dr * i]?.[c + dc * i] !== color) return false;
        }
        return true;
    }

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            if (checkDirection(r, c, 0, 1) || checkDirection(r, c, 1, 0) || checkDirection(r, c, 1, 1) || checkDirection(r, c, 1, -1)) {
                return true;
            }
        }
    }
    return false;
}

// Disable board after win
function disableBoard() {
    document.querySelectorAll(".cell").forEach(cell => {
        cell.removeEventListener("click", handleMove);
    });
}

// Reset game
resetButton.addEventListener("click", () => {
    currentPlayer = "red";
    statusText.textContent = "Red";
    createBoard();
});

// Initialize game
createBoard();
